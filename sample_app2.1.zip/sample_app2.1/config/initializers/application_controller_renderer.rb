# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'b4215e740fa708c36a6f7de470eaf21ac2c3ac2bddc799aae58d47132d0793d5b9c771942c6f9e5ca8e3d7552ff09d5811f1fb789bf5bbbe7a891dbd73ce06d7'